public class Name {
    private String fname;
    private String lname;
    private String mname;

        // below count as Set
    public Name(String fname, String mname, String lname){

        this.fname = fname;
        this.mname = mname;
        this.lname = lname;

    }


    String GetFName(){
        return fname;  // this - refers to class attributes
    }

    String GetMName(){

        return mname;
    }

    String GetLName(){

        return lname;

    }
}
