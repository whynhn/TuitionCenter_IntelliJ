public class Headmaster {

    Name headMastername;
    Address headMasterAddress;

    String hQualification;


    void SetName(Name name){
        headMastername = name;
    }


    void SetAddress(Address address){
        headMasterAddress = address;
    }

    void SetQualHead(String qual){
        hQualification =qual;
    }
}
