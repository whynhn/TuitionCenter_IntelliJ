public class Tutor {
    Name tutorName;
    String tutorIc;
    Address tutorAddress;
    int numyearexp;
    String qualification;
     int ClassSize = 4;

//    void SetClassSize(int size) {
//        this.ClassSize = size;
//    }

    public int getClassSize(){
        return ClassSize;
    }


    void SetName(Name name){
        tutorName = name;
    }

    void SetAddress(Address address){
        tutorAddress = address;
    }

    void SetExp(int exp){
        numyearexp = exp;
    }

    void SetQual(String qual){
        qualification =qual;
    }

    void SetIC(String Ic){
        tutorIc = Ic;
    }

}
